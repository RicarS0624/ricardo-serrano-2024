1
from Carritos import Auto, Motocicleta, Camion

def main():
    vehiculos = []

    while True:
        print('\n\nMENÚ PRINCIPAL')
        print('1. Registrar vehículo')
        print('2. Mostrar listado de vehículos')
        print('3. Mostrar información de un vehículo')
        print('4. Calcular costo de alquiler de un vehículo')
        print('5. Salir')
        opcion = int(input('Selecciona una opción: '))

        if opcion == 1:
            print('Registro de vehículos')
            marca = input('Marca: ')
            modelo = input('Modelo: ')
            año = int(input('Año: '))
            precio_base = float(input('Precio base por día: '))
            tipo = int(input('Tipo (1. Auto - 2. Motocicleta - 3. Camión): '))

            if tipo == 1:
                cantidad_pasajeros = int(input('Cantidad de pasajeros: '))
                vehiculo = Auto(marca, modelo, año, precio_base, cantidad_pasajeros)
            elif tipo == 2:
                cilindraje = int(input('Cilindraje: '))
                vehiculo = Motocicleta(marca, modelo, año, precio_base,cilindraje)
            elif tipo == 3:
                capacidad_carga = float(input('Capacidad de carga (toneladas): '))
                vehiculo = Camion(marca, modelo, año, precio_base,capacidad_carga)
            else:
                print('Tipo de vehículo no reconocido.')
                continue
            
            vehiculos.append(vehiculo)
            print('Vehículo registrado con éxito.')

        elif opcion == 2:
            print('Listado de vehículos:')
            for index, vehiculo in enumerate(vehiculos):
                print(f'{index + 1}. {vehiculo.mostrar_info_resumida()}')

        elif opcion == 3:
            num_vehiculo = int(input('Selecciona el número del vehículo: '))
            if 1 <= num_vehiculo <= len(vehiculos):
                print(vehiculos[num_vehiculo - 1].mostrar_info())
            else:
                print('Número de vehículo inválido.')

        elif opcion == 4:
            num_vehiculo = int(input('Selecciona el número del vehículo: '))
            if 1 <= num_vehiculo <= len(vehiculos):
                costo = vehiculos[num_vehiculo - 1].calcular_costo_alquiler()
                print(f'El costo de alquiler del vehículo es: ${costo:.2f} por día.')
            else:
                print('Número de vehículo inválido.')

        elif opcion == 5:
            print('Programa Finalizado')
            break

        else:
            print('Opción Incorrecta')

if __name__ == '__main__':
    main()
