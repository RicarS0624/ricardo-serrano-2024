from abc import ABC, abstractmethod

class Vehiculo(ABC):
    def __init__(self, marca, modelo, año, precio_base,):
        self.marca = marca
        self.modelo = modelo
        self.año = año
        self.precio_base = precio_base


    def mostrar_info_resumida(self):
        return f'{self.marca} {self.modelo} ({self.año})'

    def mostrar_info(self):
        return (f'Marca: {self.marca}\nModelo: {self.modelo}\nAño: {self.año}\nPrecio base: ${self.precio_base:.2f}')

    @abstractmethod
    def calcular_costo_alquiler(self):
        pass


class Auto(Vehiculo):
    def __init__(self, marca, modelo, año, precio_base, cantidad_pasajeros):
        super().__init__(marca, modelo, año, precio_base,)
        self.cantidad_pasajeros = cantidad_pasajeros

    def calcular_costo_alquiler(self):
        return self.precio_base * 1.05


class Motocicleta(Vehiculo):
    def __init__(self, marca, modelo, año, precio_base, cilindraje):
        super().__init__(marca, modelo, año, precio_base)
        self.cilindraje = cilindraje

    def calcular_costo_alquiler(self):
        return self.precio_base * 0.95


class Camion(Vehiculo):
    def __init__(self, marca, modelo, año, precio_base, capacidad_carga):
        super().__init__(marca, modelo, año, precio_base)
        self.capacidad_carga = capacidad_carga

    def calcular_costo_alquiler(self):
        return self.precio_base * 1.2