package taller.pkg21;

import java.util.Scanner;

/**
 *
 * @author CSU23
 */
public class Taller21 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
      String opcion = "si";
      while (opcion.toLowerCase().equals ("no")== false) {
        System.out.println("¿cuantas notas quiere poner ?");
        int cantidad = sc.nextInt();
        if(cantidad > 0 && cantidad <=10) {
            double[] notas = new double [cantidad];
           
            for (int i = 0; i < cantidad; i = i + 1 ){
                System.out.println("Nota#" + (i+ 1 ) + ":");
                double nota = sc.nextDouble ();
               
                notas[i] = nota;
            }
            double suma = 0;
            for (double nota: notas){
                suma += nota;
            }
            
            double promedio = suma / cantidad ;
            System.out.println("El promedio es" + ""+ promedio);
           
    } else {
            System.out.println("La cantidad de notas debe ser mayor ");
            opcion = sc.next();
        }
     }
      
      System.out.println("Escribe un numero entre 1 y 5:");
      int numero = sc.nextInt();
      switch (numero){
          case 1:
              System.out.println("uno");
                case 2:
              System.out.println("dos");
                case 3:
              System.out.println("tres");
          case 4:
          System.out.println("cuatro");
                case 5:
              System.out.println("cinco");
                default:
                    System.out.println("Numero incorrecto");
                    break;
               
    }
}

}
